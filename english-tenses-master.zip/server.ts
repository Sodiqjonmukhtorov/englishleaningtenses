import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Groq from "groq-sdk";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY || "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",
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.post("/api/check-translation", async (req, res) => {
    const { uzbekSentence, userTranslation, tense } = req.body;

    const prompt = `
      You are an English teacher. 
      Task: Check if the English translation of the following Uzbek sentence is correct, specifically focusing on the ${tense} tense.
      
      Uzbek sentence: "${uzbekSentence}"
      User's English translation: "${userTranslation}"
      
      Instructions:
      1. If it's correct (minor punctuation/capitalization errors are okay), set isCorrect to true.
      2. Provide a detailed explanation of any errors in Uzbek. 
         - If there's a mistake, explain exactly what is wrong (e.g., wrong auxiliary verb, incorrect verb form, spelling, or word order).
         - Explain why it's a mistake in the context of the ${tense} tense.
         - If it's correct, provide a short encouraging feedback in Uzbek.
      3. Provide the most natural correct English translation.
      
      Return the result in JSON format with the following keys:
      {
        "isCorrect": boolean,
        "feedback": "string",
        "correctAnswer": "string"
      }
    `;

    try {
      const chatCompletion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant that outputs JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        model: "llama-3.3-70b-versatile",
        response_format: { type: "json_object" },
      });

      const content = chatCompletion.choices[0]?.message?.content;
      res.json(JSON.parse(content || "{}"));
    } catch (error) {
      console.error("Groq API error:", error);
      res.status(500).json({
        isCorrect: false,
        feedback: "Kechirasiz, tekshirishda xatolik yuz berdi. Iltimos qaytadan urunib ko'ring.",
        correctAnswer: "",
      });
    }
  });

  app.post("/api/chat", async (req, res) => {
    const { messages } = req.body;

    try {
      const chatCompletion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "You are a helpful English teacher assistant. Answer questions about English grammar, tenses, and vocabulary in Uzbek. Keep your answers concise and encouraging.",
          },
          ...messages,
        ],
        model: "llama-3.3-70b-versatile",
      });

      const content = chatCompletion.choices[0]?.message?.content;
      res.json({ content });
    } catch (error) {
      console.error("Groq Chat API error:", error);
      res.status(500).json({
        content: "Kechirasiz, xatolik yuz berdi. Iltimos qaytadan urunib ko'ring.",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  if (process.env.NODE_ENV !== "production" || !process.env.VERCEL) {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }

  return app;
}

const appPromise = startServer();
export default appPromise;
