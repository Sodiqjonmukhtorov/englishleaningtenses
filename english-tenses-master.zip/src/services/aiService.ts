export interface CheckResult {
  isCorrect: boolean;
  feedback: string;
  correctAnswer: string;
}

export const checkTranslation = async (
  uzbekSentence: string,
  userTranslation: string,
  tense: string
): Promise<CheckResult> => {
  try {
    const response = await fetch("/api/check-translation", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        uzbekSentence,
        userTranslation,
        tense,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to check translation");
    }

    const result = await response.json();
    return {
      isCorrect: !!result.isCorrect,
      feedback: result.feedback || "Xatolik yuz berdi.",
      correctAnswer: result.correctAnswer || "",
    };
  } catch (error) {
    console.error("AI API error:", error);
    return {
      isCorrect: false,
      feedback: "Kechirasiz, tekshirishda xatolik yuz berdi. Iltimos qaytadan urunib ko'ring.",
      correctAnswer: "",
    };
  }
};

export const sendMessage = async (messages: { role: string; content: string }[]): Promise<string> => {
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ messages }),
    });

    if (!response.ok) {
      throw new Error("Failed to send message");
    }

    const result = await response.json();
    return result.content || "Xatolik yuz berdi.";
  } catch (error) {
    console.error("Chat API error:", error);
    return "Kechirasiz, xatolik yuz berdi. Iltimos qaytadan urunib ko'ring.";
  }
};
